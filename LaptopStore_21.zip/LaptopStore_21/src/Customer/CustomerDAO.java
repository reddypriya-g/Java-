package Customer;

import Main_Connection.*;
import CRUD.*;
import java.sql.*;
import java.util.*;

public class CustomerDAO extends Abstract_Crud {

    public static void createCustomer(Customer cs) {
        Connection con = ConnectionFactory.getConnection();
        List<Customer> cust = getCustomer_Id(cs.getCid());
        if (cust.isEmpty()) {
            final String SQL = "insert into Customer values(?,?,?,?,?)";
            try (PreparedStatement stm = con.prepareStatement(SQL)) {
                stm.setString(1, cs.getCid());
                stm.setString(2, cs.getName());
                stm.setString(3, cs.getPhn_no());
                stm.setString(4, cs.getLaptop());
                stm.setInt(5, cs.getAmount());
                stm.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Could'nt create a Customer");
                e.printStackTrace();
            }
        } else
            updateCustomer(cs);
    }

    public static List<Customer> getAllCustomers() {
        List<Customer> customer = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "select * from Customer";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Customer cs = new Customer(rs.getString("cid"), rs.getString("name"), rs.getString("Phn_no"),
                        rs.getString("laptop"), rs.getInt("Amount"));
                customer.add(cs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    public static void updateCustomer(Customer cs) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "update Customer set name=?, phn_no=?,laptop=?,amount=? where cid=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(5, cs.getCid());
            stm.setString(1, cs.getName());
            stm.setString(2, cs.getPhn_no());
            stm.setString(3, cs.getLaptop());
            stm.setInt(4, cs.getAmount());
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteCustomer_id(String cid) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from Customer where cid = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, cid);
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteCustomer_name(String name) {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "delete from Customer where name = ?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, name);
            rows(stm);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void DeleteAll() {
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "truncate table Customer";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Deleted Succesfully");
        }
    }

    public static List<Customer> getCustomer_name(String pname) {
        // Implemented using Partial Strings
        List<Customer> customer = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "SELECT * FROM Customer WHERE name like concat('%',?,'%')";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, pname);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Customer cs = new Customer(rs.getString("cid"), rs.getString("name"), rs.getString("Phn_no"),
                        rs.getString("laptop"), rs.getInt("Amount"));
                customer.add(cs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(customer.size() + " rows found");
        return customer;
    }

    public static List<Customer> getCustomer_Id(String id) {
        List<Customer> customer = new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        final String SQL = "SELECT * FROM Customer WHERE cid=?";
        try (PreparedStatement stm = con.prepareStatement(SQL)) {
            stm.setString(1, id);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Customer cs = new Customer(rs.getString("cid"), rs.getString("name"), rs.getString("Phn_no"),
                        rs.getString("laptop"), rs.getInt("Amount"));
                customer.add(cs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }
}
