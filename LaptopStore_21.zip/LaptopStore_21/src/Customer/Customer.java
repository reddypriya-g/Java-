package Customer;

public class Customer {
    private String cid;
    private String name;
    protected String phn_no;
    protected String laptop;
    private int amount;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhn_no() {
        return phn_no;
    }

    public void setPhn_no(String phn_no) {
        this.phn_no = phn_no;
    }

    public String getLaptop() {
        return laptop;
    }

    public void setLaptop(String laptop) {
        this.laptop = laptop;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Customer(String cid, String name, String phn_no, String laptop, int amount) {
        this.cid = cid;
        this.name = name;
        this.phn_no = phn_no;
        this.laptop = laptop;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return getCid() + "  |  " + getName() + " \t|  " + getPhn_no() + "\t |   " + getLaptop() + "  \t |  "
                + getAmount();

    }

    public Customer(String customer) {
        String values[] = customer.split(",");
        this.cid = values[0];
        this.name = values[1];
        this.phn_no = values[2];
        this.laptop = values[3];
        this.amount = Integer.valueOf(values[4]);

    }
}
