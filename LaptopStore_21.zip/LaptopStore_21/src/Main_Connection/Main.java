package Main_Connection;

import CRUD.*;
import Customer.*;
import laptop.Laptop;

import java.io.*;
import java.util.*;

public class Main extends Abstract_Crud {
    public static void help() {
        System.out.println("--------------------Commands for Mini Project---------------------");
        System.out.println(" LOAD CSV  LAPTOP        : -loadLP");
        System.out.println(" LOAD CSV  CUSTOMER      : -loadCS");
        System.out.println(" CREATE LAPTOP           : -createLP 'id' 'name' 'price' 'availability'");
        System.out.println(" CREATE CUSTOMER         : -createCS 'cid' 'name' 'phn_no' 'laptop' 'amount'");
        System.out.println(" PRINT All  LAPTOPS      : -printAll lp  ");
        System.out.println(" PRINT All  CUSTOMER     : -printAll cs  ");
        System.out.println(" UPDATE LAPTOP           : -updateLP 'id' 'name' 'price' 'availability' ");
        System.out.println(" UPDATE CUSTOMER         : -updateCS 'cid' 'name' 'phn_no' 'laptop' 'amount'");
        System.out.println(" DELETE LAPTOP BY ID     : -delete lp id 'id'");
        System.out.println(" DELETE CUSTOMER BY ID   : -delete cs id 'id'");
        System.out.println(" DELETE LAPTOP BY NAME   : -delete lp name 'name'");
        System.out.println(" DELETE CUSTOMER BY NAME : -delete cs name 'name'");
        System.out.println(" DELETE ALL LAPTOPS      : -truncate lp");
        System.out.println(" DELETE ALL CUSTOMERS    : -truncate cs");
        System.out.println(" SEARCH LAPTOP BY NAME   : -search lp name 'name'");
        System.out.println(" SEARCH LAPTOP BY ID     : -search lp id 'id'");
        System.out.println(" SEARCH LAPTOP BY PRICE  : -search lp price 'price'");
        System.out.println(" SEARCH CUSTOMER BY NAME : -search cs name 'name'");
        System.out.println(" SEARCH CUSTOMER BY ID   : -search cs id 'id'");
        System.out.println(" GET LAPTOP < PRICE      : -price lt 'price'");
        System.out.println(" GET LAPTOP > PRICE      : -price gt 'price'");
        System.out.println(" GET LAPTOP IN RANGE     : -price btw 'price1' 'price2'");
        System.out.println(" AVERAGE                 : -price avg 'name'");
        System.out.println(" GET AVAILABILITY        : -gtAvail ");
        System.out.println(" SORT BY PRICE           : -price sort");
        System.out.println(" For Help                : -h ");
    }

    public static void main(String[] args) throws Exception {
        switch (args[0]) {
            case "-loadLP" -> {
                try {
                    BufferedReader reader = new BufferedReader(
                            new FileReader(
                                    "C:\\Users\\hi\\OneDrive\\Desktop\\LaptopStore_21\\laptops.csv"));
                    String laptopLine;
                    while ((laptopLine = reader.readLine()) != null) {
                        Create.createLaptop(new Laptop(laptopLine));
                    }
                    List<Laptop> lp = new ArrayList<>();
                    lp = GetLaptop.getAllLaptops();
                    printlp(lp);
                    count("laptop");
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    System.out.println("laptops.CSV loaded Successfully");
                }
            }

            case "-loadCS" -> {
                try {
                    BufferedReader reader = new BufferedReader(
                            new FileReader(
                                    "C:\\Users\\hi\\OneDrive\\Desktop\\LaptopStore_21\\customers.csv"));
                    String customerLine;
                    while ((customerLine = reader.readLine()) != null) {
                        CustomerDAO.createCustomer(new Customer(customerLine));
                    }
                    List<Customer> cs = new ArrayList<>();
                    cs = CustomerDAO.getAllCustomers();
                    printcs(cs);
                    count("customer");
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    System.out.println("Customers.CSV loaded Successfully");
                }
            }

            case "-createLP" -> {
                String id = (args[1]);
                String name = args[2];
                int price = Integer.parseInt(args[3]);
                String availability = args[4];
                Laptop lp = new Laptop(id, name, price, availability);
                Create.createLaptop(lp);
                printlp(GetLaptop.getAllLaptops());
            }

            case "-createCS" -> {
                String cid = args[1];
                String name = args[2];
                String phn_no = args[3];
                String laptop = args[4];
                int amount = Integer.parseInt(args[5]);
                Customer cs = new Customer(cid, name, phn_no, laptop, amount);
                CustomerDAO.createCustomer(cs);
                printcs(CustomerDAO.getAllCustomers());
            }

            case "-printAll" -> {
                if (args[1].equals("lp"))
                    printlp(GetLaptop.getAllLaptops());
                if (args[1].equals("cs"))
                    printcs(CustomerDAO.getAllCustomers());
            }

            case "-updateLP" -> {
                String id = (args[1]);
                String name = args[2];
                int price = Integer.parseInt(args[3]);
                String availability = args[4];
                Laptop c1 = new Laptop(id, name, price, availability);
                Update.updateLaptop(c1);
                printlp(GetLaptop.getAllLaptops());
            }

            case "-updateCS" -> {
                String cid = (args[1]);
                String name = args[2];
                int amount = Integer.parseInt(args[5]);
                String laptop = args[4];
                String phn_np = args[3];
                Customer cs = new Customer(cid, name, phn_np, laptop, amount);
                CustomerDAO.updateCustomer(cs);
                printcs(CustomerDAO.getAllCustomers());
            }

            case "-delete" -> {
                if (args[1].equals("lp")) {
                    if (args[2].equals("id")) {
                        Update.deleteLaptop_id(args[3]);
                        printlp(GetLaptop.getAllLaptops());
                    }
                    if (args[2].equals("name")) {
                        Update.deleteLaptop_name(args[3]);
                        printlp(GetLaptop.getAllLaptops());
                    }
                } else if (args[1].equals("cs")) {
                    if (args[2].equals("id")) {
                        CustomerDAO.deleteCustomer_id(args[3]);
                        printcs(CustomerDAO.getAllCustomers());
                    }
                    if (args[2].equals("name")) {
                        CustomerDAO.deleteCustomer_name(args[3]);
                        printcs(CustomerDAO.getAllCustomers());
                    }
                }

            }

            case "-truncate" -> {
                if (args[1].equals("lp")) {
                    Update.DeleteAll();
                } else if (args[1].equals("cs")) {
                    CustomerDAO.DeleteAll();
                }
            }

            case "-search" -> {
                if (args[1].equals("lp")) {
                    if (args[2].equals("name"))
                        printlp(GetLaptop.getLaptop_name(args[3]));
                    if (args[2].equals("id"))
                        printlp(GetLaptop.getLaptop((args[3])));
                    if (args[2].equals("price"))
                        printlp(GetLaptop.getLaptop(Integer.parseInt(args[3])));
                }
                if (args[1].equals("cs")) {
                    if (args[2].equals("name"))
                        printcs(CustomerDAO.getCustomer_name(args[3]));
                    if (args[2].equals("id"))
                        printcs(CustomerDAO.getCustomer_Id(args[3]));
                }
            }

            case "-price" -> {
                if (args[1].equals("lt"))
                    printlp(Aggregate.getLaptopByprice(Integer.parseInt(args[2]), args[1]));
                if (args[1].equals("gt"))
                    printlp(Aggregate.getLaptopByprice(Integer.parseInt(args[2]), args[1]));
                if (args[1].equals("sort"))
                    printlp(Aggregate.SortByPrice());
                if (args[1].equals("btw"))
                    printlp(Aggregate.getLaptopBetweenprice(Integer.parseInt(args[2]), Integer.parseInt(args[3])));
                if (args[1].equals("avg"))
                    Aggregate.getAvgPrice(args[2]);
            }

            case "-gtAvail" -> printlp(GetLaptop.getbyAvailability());

            case "-h" -> help();

            default -> {
                System.out.println("\n\nCOMMAND NOT FOUND");
                help();
            }
        }
    }
}